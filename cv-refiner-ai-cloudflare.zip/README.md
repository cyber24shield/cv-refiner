# CV Refiner AI

A small full-stack CV-tailoring MVP: static frontend + Cloudflare Worker API + Google Gemini API. Designed for GitHub-connected Cloudflare Workers deployment.

## Features
- Upload PDF, DOCX, or TXT and extract text in the browser.
- Tailor the CV to a target job title, experience level, industry/location, and pasted job description.
- Gemini-powered rewrite with explicit anti-fabrication instructions.
- Copy, download plain text, or print/save as PDF.
- No database and no intentional server-side CV storage.

## Project structure
- `public/index.html` — frontend
- `worker.js` — API endpoint and Gemini proxy
- `wrangler.toml` — Cloudflare Worker + static assets configuration

## Deploy with Cloudflare
1. Push this project to a GitHub repository.
2. In Cloudflare, create a Worker and connect the GitHub repository (Workers & Pages → Create → Workers → Connect to Git).
3. Build/deploy configuration:
   - Build command: leave empty
   - Deploy command: `npx wrangler deploy`
   - Root directory: `/` (repository root)
4. Add a Worker secret named `GEMINI_API_KEY` in Worker settings, or run `npx wrangler secret put GEMINI_API_KEY` in a local terminal and paste the key when prompted. Never put the key in `index.html`, `wrangler.toml`, GitHub, or any public file.
5. Deploy and test `https://YOUR-WORKER-URL/api/health`; expected response: `{"ok":true,"service":"CV Refiner AI"}`.
6. Open the Worker URL, upload a text-based PDF/DOCX/TXT, enter a target job title, and refine.

Cloudflare configuration labels may vary slightly by dashboard version. The project uses a Worker because the Gemini API key must stay server-side; a static-only Pages direct upload is not sufficient for secure API access.

## Local development
Requires Node.js and npm:
```bash
npm install -D wrangler
npx wrangler dev
```
Set the secret for local development using a `.dev.vars` file:
```text
GEMINI_API_KEY=your_key_here
```
Do not commit `.dev.vars`; add it to `.gitignore` before use. Alternatively use Wrangler's secret commands. Then open the local URL shown by Wrangler.

## Gemini key
Create/manage your key in Google AI Studio: https://aistudio.google.com/app/apikey
Use a current key supported by Google's current Gemini API requirements. Keep it secret and restrict it appropriately. Gemini usage can incur quota limits or charges depending on your account and model.

## Limitations of this starter
- Scanned/image-only PDFs may not extract text; use OCR or convert to a text-based document.
- PDF/DOCX extraction libraries load from public CDNs, so internet access is needed for those formats. TXT is a fallback.
- The result is a text-first CV. Print/save as PDF from your browser; native DOCX export, user accounts, rate limiting, and persistent saved versions are not included yet.
- The API endpoint has basic validation but is not production-hardened against abuse. Before public launch, add rate limiting, abuse controls, privacy/retention terms, and optionally authentication.
- Review the output carefully before using it. The AI must not invent experience or qualifications.
